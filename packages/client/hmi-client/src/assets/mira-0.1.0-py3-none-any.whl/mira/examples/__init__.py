"""Examples for MIRA."""
