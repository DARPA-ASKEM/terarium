# -*- coding -*-: utf-8

"""Run the database indexing using ``python -m mira.dkg.indexing``."""

from .cli import main

if __name__ == "__main__":
    main()
