"""Tests for generators."""
